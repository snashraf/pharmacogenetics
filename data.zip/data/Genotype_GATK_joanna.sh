module load Java/1.7.0_79
# SETTINGS
which java
java -version

ref="/hpc/cog_bioinf/GENOMES/Homo_sapiens.GRCh37.GATK.illumina/Homo_sapiens.GRCh37.GATK.illumina.fasta"
snp="/hpc/cog_bioinf/data/jwolthuis/Pharmacogenetics/new_design.vcf"
gatk="/hpc/cog_bioinf/common_scripts/GenomeAnalysisTK-3.2-0/GenomeAnalysisTK.jar"
call="HaplotypeCaller"
#UnifiedGenotyper"
panel="WGS_PharmacoGenomics"

# First argument is bamfolder
folder="/hpc/cog_bioinf/data/jwolthuis/Pharmacogenetics/bamlinks"
outfolder="/hpc/cog_bioinf/data/jwolthuis/Pharmacogenetics/new_output"

for bam in $folder/*.bam; do
	filename=${bam##*/}
	samplename=${filename%.*}
	outfile="${outfolder}/${samplename}_${panel}.vcf"

	echo $samplename
	echo $outfile
	java -Xms2g -Xmx9g -jar ${gatk} -T ${call} -R ${ref} -L ${snp} --dbsnp ${snp} --output_mode EMIT_ALL_SITES -I ${bam} -o ${outfile}
done
