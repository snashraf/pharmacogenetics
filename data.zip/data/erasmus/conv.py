import pandas as pd
import os
import re

def all_getter(sh, co, rs):
    cut = re.split("[, */\-()!.?:]+", sh)
    # get gene name
    gene_name = cut[0]
    # get haplotype symbol
    locs = []
    haps = []
    for item in cut:
        if ">" in item or "del" in item:
            locs.append(item)
        elif len(item) > 1 and "c" not in item and "g" not in item and "rs" not in item and "-" not in item and gene_name not in item :
            haps.append("*"+item)
    if len(haps) == 0:
        haps = ""
    if len(locs) == 0:
        locs = co
    return(gene_name, locs, haps)
    # add RS

cwd = os.getcwd()
loc = cwd + "/hap.csv"

haptab = pd.read_csv(loc)

genes = haptab['Gene'].values

loc = cwd + "/snp.csv"

subset = haptab[['Gene','Common Allele Name','allele','dbSNP','hg19']]
tab = subset.drop(0)

genes = []
rs_hap = {}
gene_hap = {}

for i, row in tab.iterrows():
    gene = row['Gene']
    rs = row['dbSNP']
    co_allele = row['allele']
    sh_allele = row['Common Allele Name']
    results = all_getter(sh_allele, co_allele, rs)
    gene = results[0]
    for item in results[1::]:
        print item


