module load Java/1.7.0_79
# SETTINGS
which java
java -version

ref="/hpc/cog_bioinf/GENOMES/Homo_sapiens.GRCh37.GATK.illumina/Homo_sapiens.GRCh37.GATK.illumina.fasta"
snp="/hpc/cog_bioinf/data/PROJECTS/Pharmacogenetics/pharmacogenetica_design.vcf"
gatk="/hpc/cog_bioinf/common_scripts/GenomeAnalysisTK-3.2-0/GenomeAnalysisTK.jar"
call="HaplotypeCaller"
#UnifiedGenotyper"
panel="WGS_PharmacoGenomics"

# First argument is bamfolder
folder="/hpc/cog_bioinf/data/PROJECTS/Pharmacogenetics/bamlinks"
outfolder="/hpc/cog_bioinf/data/PROJECTS/Pharmacogenetics/output"

function join_by { local d=$1; shift; echo -n "$1"; shift; printf "%s" "${@/#/$d}"; }

for bam in $folder/*.bam; do
	filename=${bam##*/}
	samplename=${filename%.*}
	outfile="${outfolder}/${samplename}_${panel}.vcf"

	echo $samplename
	echo $outfile
	java -Xms2g -Xmx9g -jar ${gatk} -T ${call} -R ${ref} -L ${snp} --dbsnp ${snp} -ERC GVCF -I ${files} -o ${oufile}.g.vcf
done

filelist=($outfolder/*g.vcf)
files=$(join_by ' --variant ' "${filelist[@]}")

java -Xms2g -Xmx9g -jar ${gatk} -T GenotypeGVCFs -R ${ref} --variant ${files} -o ${otfolder}/ALL_${panel}.vcf
#done
